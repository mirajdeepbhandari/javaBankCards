
public class DebitCard extends BankCard {
    /*
     * Declare a class called DebitCard that extends the class BankCard, this
     * class is used to model the debit card functionality
     */

    private int pinNumber;
    /*
     * Declare a private variable called pinNumber, this variable will store the pin
     * number of the debit card
     */

    private int withdrawalAmount;
    /*
     * Declare a private variable called withdrawalAmount, this variable will store
     * the withdrawal amount of the debit card
     */

    private String dateofWithdrawal;
    /*
     * Declare a private variable called dateofWithdrawal, this variable will store
     * the date of withdrawal of the debit card
     */

    private boolean hasWithdrawn;
    //Declare a private variable called hasWithdrawn, this variable will indicate whether the debit card has been used for withdrawal or not
      
     
    
    // Constructor for DebitCard class
    public DebitCard(int balanceAmount, int cardId, String bankAccount, String issuerBank, String clientName,int pinNumber)
    {

        super(balanceAmount, cardId, bankAccount, issuerBank);
        /*
         * Call the constructor of the parent class and pass the
         * parameters, this will initialize the properties
         * inherited from the BankCard class
         */

        setClientName(clientName);
        /*
         * Call the setter method to set the clientName, this will set the name of the
         * client who owns the debit card
         */

        this.pinNumber = pinNumber;
        /*
         * Assign the parameter pinNumber to the instance variable pinNumber, this will
         * set the pin number of the debit card
         */

        this.hasWithdrawn = false;
        /*
         * Assign the value false to the instance variable hasWithdrawn, this will
         * indicate that the debit card has not been used for withdrawal
         */

    }

    
    // Declare a public method called getPinNumber that returns an integer
    public int getPinNumber() 
    {
        return this.pinNumber;
        /*
         * Return the value of the instance variable pinNumber, this method provides
         * access to the private pinNumber variable
         */
    }

    
    // Declare a public method called getWithdrawalAmount that returns an integer
    public int getWithdrawalAmount()
    {
        return this.withdrawalAmount;
        /*
         * Return the value of the instance variable withdrawalAmount, this method
         * provides access to the private withdrawalAmount variable
         */
    }

    
    // Declare a public method called getDateofWithdrawal that returns a String
    public String getDateofWithdrawal() 
    {
        return this.dateofWithdrawal;
        /*
         * Return the value of the instance variable dateofWithdrawal, this method
         * provides access to the private dateofWithdrawal variable
         */
    }

    
    // Declare a public method called getHasWithdrawn that returns a boolean
    public boolean getHasWithdrawn() 
    {
        return this.hasWithdrawn;
        /*
         * Return the value of the instance variable hasWithdrawn, this method provides
         * access to the private hasWithdrawn variable
         */

    }

    
    
    // Declare a public method called setWithdrawalAmount that takes an integer as parameter
    public void setWithdrawalAmount(int withdrawalAmount) 
    {

        this.withdrawalAmount = withdrawalAmount;
        /*
         * Assign the value of the parameter withdrawalAmount to the instance
         * variable withdrawalAmount, this method allows to change the value
         * of the private withdrawalAmount variable
         */

    }

    
    
    
    // Declare a public method called withdraw that takes three parameters, an int,a String, and an int
    public void withdraw(int withdrawalAmount, String dateofWithdrawal, int pinNumber)
    {

        // Check if the given pin number matches the pin number of the debit card
        if (pinNumber == this.pinNumber)
        {

            // Check if the withdrawal amount is less than or equal to the balance amount
            if (withdrawalAmount <= getBalanceAmount())
             {

                // subtract the withdrawal amount from the balance amount
                setBalanceAmount(getBalanceAmount() - withdrawalAmount);

                // Assign the value of the parameter withdrawalAmount to the instance variable withdrawalAmount
                this.withdrawalAmount = withdrawalAmount;

                // Assign the value of the parameter dateofWithdrawal to the instance variable dateofWithdrawal
                this.dateofWithdrawal = dateofWithdrawal;
                
                // Assign the value true to the instance variable hasWithdrawn
                this.hasWithdrawn = true; 

                // Print a message indicating that the transaction was successful
                System.out.println("Transaction successful. Your new balance: " + getBalanceAmount());
 
             } 
            
            else 
             {
                
                // If the withdrawal amount is greater than the balance amount, print a message indicating insufficient funds
                System.out.println("Insufficient funds. You cannot withdraw ");

             }
            } 
        
          else
          {
            
            // If the pin number does not match,print a message indicating that the pin is invalid
            System.out.println("The pin is invalid please! Enter correct pin");

          }
    }

    // Declare a public method called display
    public void display() 
    {

      // Check if the value of hasWithdrawn is true
        if (hasWithdrawn == true)
      {
            super.display(); // Call the display method of the parent class
            System.out.println("Pin Number: " + pinNumber); // Print the value of pinNumber
            System.out.println("Withdrawal Amount: " + withdrawalAmount); // Print the value of withdrawalAmount
            System.out.println("Date of Withdrawal: " + dateofWithdrawal); // Print the value of dateofWithdrawal

      // If the value of hasWithdrawn is false, print the balance amount
      } 
        
       else
      {     super.display(); 
            
      }
     
     
    }

}
