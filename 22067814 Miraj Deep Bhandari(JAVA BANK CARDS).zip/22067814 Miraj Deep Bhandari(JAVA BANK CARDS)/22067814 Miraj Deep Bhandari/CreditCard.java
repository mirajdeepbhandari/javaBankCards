public class CreditCard extends BankCard { // Declare a class called CreditCard that extends the class BankCard

    private int cvcNumber; // Declare a private variable called cvcNumber
    
    private double creditLimit; // Declare a private variable called creditLimit
    
    private double interestRate; // Declare a private variable called interestRate
    
    private String expirationDate; // Declare a private variable called expirationDate
    
    private int gracePeriod; // Declare a private variable called gracePeriod
    
    private boolean isGranted; // Declare a private variable called isGranted
    
    
    
    //constructor of CreditCard class
    public CreditCard(int cardId, String clientName, String issuerBank, String bankAccount, int balanceAmount,int cvcNumber, double interestRate, String expirationDate)
    { 
        
        
        // Call the constructor of the parent class and pass the parameters
        super( balanceAmount, cardId, bankAccount, issuerBank);
        

        // Call the setter method to set the clientName
        setClientName(clientName);
        

        // Assign the parameter cvcNumber to the instance variable cvcNumber
        this.cvcNumber = cvcNumber;
        

        // Assign the parameter interestRate to the instance variable interestRate
        this.interestRate = interestRate;
        

        // Assign the parameter expirationDate to the instance variable expirationDate
        this.expirationDate = expirationDate;
        

        // Assign the value false to the instance variable isGranted
        this.isGranted = false;
        
        
    }

    
    
    
    // Declare a public method called getCvcNumber that returns an integer
    public int getCvcNumber()
    {
        
        return this.cvcNumber; // Return the value of the instance variable cvcNumber
        
    }

    
    
    
    // Declare a public method called getCreditLimit that returns a double
    public double getCreditLimit() 
    {
        
        return this.creditLimit; // Return the value of the instance variable creditLimit
        
    }

    
    
    
    // Declare a public method called getInterestRate that returns a double
    public double getInterestRate() 
    {
        
        return this.interestRate; // Return the value of the instance variable interestRate
        
    }

    
    
    
    // Declare a public method called getExpirationDate that returns a String
    public String getExpirationDate() 
    {
        
        return this.expirationDate; // Return the value of the instance variable expirationDate
        
    }

    
    
    
    // Declare a public method called getGracePeriod that returns an integer
    public int getGracePeriod() 
    {
        
        return this.gracePeriod; // Return the value of the instance variable gracePeriod
        
    }

    
    
    
    // Declare a public method called getIsGranted that returns a boolean
    public boolean getIsGranted() 
    {
        
        return this.isGranted; // Return the value of the instance variable isGranted
        
    }

    
    
    
     
    // Declare a public method called setCreditLimit that takes two parameters, a double and an int
    public void setCreditLimit(double creditLimit, int gracePeriod)
    {
    
        //Check if the given credit limit is less than or equal to 2.5 times the balance amount
        if (creditLimit <= 2.5 * getBalanceAmount())
        {

            // Assign the value of the parameter creditLimit to the instance variable creditLimit
            this.creditLimit = creditLimit;

            
             // Assign the value of the parameter gracePeriod to the instance variable gracePeriod
            this.gracePeriod = gracePeriod;
            
            
            // Assign the value true to the instance variable isGranted
            this.isGranted = true;
            
            //displaying the credit limit granted information
            System.out.println("Credit granted. \nCredit limit: $" + this.creditLimit +"\n"+"Grace period: " + this.gracePeriod+" days");
            

        }
        
        // if the condition is not true then print the message.
        else
        {
           
            System.out.println("you cannot grant credit.");
            
        }
    
    }
    

    
    
    // Declare a public method called cancelCreditCard
    public void cancelCreditCard() 
    {

        // Assign the value 0 to the instance variable cvcNumber
        this.cvcNumber = 0;

        // Assign the value 0 to the instance variable creditLimit
        this.creditLimit = 0;

        // Assign the value 0 to the instance variable gracePeriod
        this.gracePeriod = 0;

        // Assign the value false to the instance variable isGranted
        this.isGranted = false;
        
    }

    
    
    
    // Declare a public method called display
    public void display()
    { 
        
        super.display(); // Call the display method of the parent class
        
        // Check if the value of isGranted is true
        if (isGranted == true) 
        { 
            
            System.out.println("Your CVC Number: " + cvcNumber); // Print the value of cvcNumber
            System.out.println("Your Credit Limit: " + creditLimit); // Print the value of creditLimit
            System.out.println("Your Grace Period: " + gracePeriod); // Print the value of gracePeriod
            System.out.println("Your Interest Rate: " + interestRate); // Print the value of interestRate
            System.out.println("Your Expiration Date: " + expirationDate); // Print the value of expirationDate

        } 
        
        // If the value of isGranted is false
        else 
        { 
            
            System.out.println("Your CVC Number: " + cvcNumber); // Print the value of cvcNumber
            System.out.println("Your Interest Rate: " + interestRate); // Print the value of interestRate
            System.out.println("Your Expiration Date: " + expirationDate); // Print the value of expirationDate
            
        }
    }

}