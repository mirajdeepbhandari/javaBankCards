public class BankCard {
    
    /*
     * This line declares the beginning of the BankCard class definition.The public keyword means that the class can be accessed by any code.
     * The class keyword indicates that this is a class definition,and BankCard is the name of the class. The curly brace { marks the beginning of the class body.
     */

    private int cardId;
    /*
     * This line declares a field, or variable, called cardId of type int. The private keyword means that this field can only be accessed within the BankCard class. .
     */

    private String clientName;
    /*
     * This line declares a field called clientName of type String. A String is a data type that represents a sequence of characters. .
     */

    private String issuerBank;
    // This line declares a field called issuerBank of type String.

    private String bankAccount;
    // This line declares a field called bankAccount of type int.

    private int balanceAmount;
    // This line declares a field called balanceAmount of type integer.

    
    // creating constructor with four arguments: balanceAmount, cardId, bankAccount,and issuerBank.
    public BankCard(int balanceAmount, int cardId, String bankAccount, String issuerBank)
    {

        // this keyword is used to refer instance variables.

        this.balanceAmount = balanceAmount;
        /*
         * assigns the value of the balanceAmount parameter to the balanceAmount
         * instance variable.
         */

        this.cardId = cardId;
        // assigns the value of the cardId parameter to the cardId instance variable.

        this.bankAccount = bankAccount;
        /*
         * assigns the value of the bankAccount parameter to the bankAccount instance
         * variable.
         */

        this.issuerBank = issuerBank;
        /*
         * assigns the value of the issuerBank parameter to the issuerBank instance
         * variable.
         */

        this.clientName = "";
        /*
         * assigns the value of the clientName parameter to the clientName instance
         * variable.
         */

    }

    
    //the getter and setter methods allow other classes to access or modify the values of the private properties of an object of the class.
    
     
    // Method to return the credit card's ID number
    public int getCardId()
    {
        return this.cardId; // this method returns the cardId property of the class
        
    }

    
    // Method to return the credit card holder's name
    public String getClientName() 
    {
        return this.clientName; // this method returns the clientName property of the class
        
    }

    
    // Method to return the issuer bank's name
    public String getIssuerBank()
    {
        return this.issuerBank; // this method returns the issuerBank property of the class
        
    }

    
    // Method to return the bank account number associated with the credit card
    public String getBankAccount() 
    {
        return this.bankAccount; // this method returns the bankAccount property of the class
        
    }

    
    // Method to return the current balance amount on the credit card
    public int getBalanceAmount()
    {
        return this.balanceAmount; // this method returns the balanceAmount property of the class
    }

    
    // Method to set the credit card holder's name
    public void setClientName(String clientName)
    {
        this.clientName = clientName;
        // this method sets the clientName property of the class to the value passed in the parameter
         
    }

    
    // Method to set the current balance amount on the credit card
    public void setBalanceAmount(int balanceAmount)
    {
        this.balanceAmount = balanceAmount;
        // this method sets the balanceAmount property of the class to the value passed in the parameter

    }

    
    // Method to display the credit card's information
    public void display() 
    {
        // Check if the client name has been assigned
        if (clientName.equals("")) 
        {
            System.out.println("The Client name is not assigned."); // print clientName property
            System.out.println("The Card ID is: " + cardId); // print cardId property
            System.out.println("The Issuer Bank is: " + issuerBank); // print issuerBank property
            System.out.println("The Bank Account is: " + bankAccount); // print bankAccount property
            System.out.println("The Balance Amount is: " + balanceAmount); // print balanceAmount property
        }

        else
        {   System.out.println("The Client name is: "+ clientName);
            System.out.println("The Card ID is: " + cardId); // print cardId property
            System.out.println("The Issuer Bank is: " + issuerBank); // print issuerBank property
            System.out.println("The Bank Account is: " + bankAccount); // print bankAccount property
            System.out.println("The Balance Amount is: " + balanceAmount); // print balanceAmount property

        }
    }

}
