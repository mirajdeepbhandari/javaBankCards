//importing the required libraries.
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;

public class BankGui implements ActionListener {
    // Declare variables for the main frame and four panels
    private JFrame jf;
    private JPanel jp, jp2, jp3, jp4;

    // Declare variables for labels to be displayed on the panels
    private JLabel heading_1, clinetname_label1, cardid_label1, bankaccount_label1, balanceamount_label1, pinnumber_label1,
            withdrawalamount_label1, withdrawaldate_label1, heading_2, clinetname_label2, cardid_label2,
            bankaccount_label2, balanceamount_label2, pinnumber_label2, interestrate_label1, expirationdate_label1,
            issuerbank_label1, issuerbank_label2, creditlimit_label1, graceperiod_label1, cardid_label3,
            withdrawalamount_label3, pinnumber_label3, heading_3, dateofwithdrawal_label3, cardid_label3_credit;

    // Declare variables for text fields to allow user input
    private JTextField clientname_input1, cardid_input1, bankaccount_input1, bankamount_input1, pin_input1,
            withdrawalamount_input1, clientname_input2, cardid_input2, bankaccount_input2, bankamount_input2,
            cvc_input1, interestrate_input1, issuerbank_input1, issuerbank_input2, creditlimit_input1,
            graceperiod_input1, cardid_input3, withdrawalamount_input3, pinnumber_input3, cardid_input3_credit;

    // Declare variables for drop-down menus to allow user input of dates
    private JComboBox <String> withdrawaldate_year, withdrawaldate_month, withdrawaldate_day, expirationdate_year, expirationdate_month,
            expirationdate_day, withdrawaldate_year3, withdrawaldate_month3, withdrawaldate_day3;

    // Declare variables for buttons that the user can click on
    private JButton withdraw_button, setcreditlimit_button, add_button1, add_button2, cancelcredit_button, display_button1,
            display_button2, clear_button1, clear_button2, gotocredit_button, gotodebit_button, proceed_button,
            goback_button, confirm_button, clear_button3, confirm_button1;
            
     // Declare an array list to store BankCard objects
    private ArrayList<BankCard> bankCards = new ArrayList<BankCard>();


    public BankGui() {
        
        // Create a JFrame object  and set its size and background color
        jf = new JFrame("BANK CARD");
        jf.setBounds(300, 100, 1000, 640);
        
           
        // Create a JPanel object and set its size and background color(Debit Card Panel)
        jp = new JPanel();
        jp.setSize(1000, 640);
        jp.setBackground(new Color(245, 245, 245));
        

        // Create a JPanel object and set its size and background color(Credit Card Panel)
        jp2 = new JPanel();
        jp2.setSize(1000, 640);
        jp2.setBackground(new Color(245, 245, 245));
        

        // Create a JPanel object and set its size and background color(withdraw Card Panel)
        jp3 = new JPanel();
        jp3.setSize(1000, 640);
        jp3.setBackground(new Color(245, 245, 245));
        

        // Create a JPanel object and set its size and background color(CreditLimit set Card Panel)
        jp4 = new JPanel();
        jp4.setBounds(0, 515, 1000, 182);
        jp4.setBackground(new Color(225, 225, 228));
        

        //heading for debit card panel
        heading_1 = new JLabel(
                "<html><span style='font-size: 27px; font-weight: bold; text-shadow: 2px 2px 2px #000; color:#CD2D0A;'> DEBIT CARD</span></html>");
        heading_1.setBounds(380, 1, 400, 70);
        

        //heading for credit card panel
        heading_2 = new JLabel(
                "<html><span style='font-size: 27px; font-weight: bold; text-shadow: 2px 2px 2px #000; color:#CD2D0A;'> CREDIT CARD</span></html>");
        heading_2.setBounds(380, 1, 400, 70);
        
        
    
        // Create a JLabel object for the client name label for the Debit Card panel
        clinetname_label1 = new JLabel("Client Name :");
        clinetname_label1.setBounds(24, 105, 200, 24);
        clinetname_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the client name label for the Credit Card panel
        clinetname_label2 = new JLabel("Client Name :");
        clinetname_label2.setBounds(42, 105, 200, 24);
        clinetname_label2.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the card id label for the Debit Card panel
        cardid_label1 = new JLabel("Card Id :");
        cardid_label1.setBounds(595, 105, 200, 24);
        cardid_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the card id label for the credit Card panel
        cardid_label2 = new JLabel("Card Id :");
        cardid_label2.setBounds(590, 105, 200, 24);
        cardid_label2.setFont(new Font("Arial", Font.BOLD, 21));
        
        
        // Create a JLabel object for the bank account label for the Debit Card panel
        bankaccount_label1 = new JLabel("Bank Account :");
        bankaccount_label1.setBounds(24, 251, 200, 24);
        bankaccount_label1.setFont(new Font("Arial", Font.BOLD, 21));
        
        
        // Create a JLabel object for the bank account label for the Credit Card panel
        bankaccount_label2 = new JLabel("Bank Account :");
        bankaccount_label2.setBounds(42, 213, 200, 24);
        bankaccount_label2.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Balance Amount label for the Debit Card panel
        balanceamount_label1 = new JLabel("Balance Amount :");
        balanceamount_label1.setBounds(595, 256, 200, 24);
        balanceamount_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Balance Amount label for the Debit Card panel
        balanceamount_label2 = new JLabel("Balance Amount :");
        balanceamount_label2.setBounds(590, 213, 200, 24);
        balanceamount_label2.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the pin number label for the withdraw  panel
        pinnumber_label1 = new JLabel("Pin Number :");
        pinnumber_label1.setBounds(24, 397, 200, 24);
        pinnumber_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the cvc label for the credit Card panel
        pinnumber_label2 = new JLabel("CVC Number :");
        pinnumber_label2.setBounds(42, 324, 200, 24);
        pinnumber_label2.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the interset rate for the credit Card panel
        interestrate_label1 = new JLabel("Interest Rate :");
        interestrate_label1.setBounds(590, 324, 200, 24);
        interestrate_label1.setFont(new Font("Arial", Font.BOLD, 21));
        
        
        // Create a JLabel object for the Expiration Date for the credit Card panel
        expirationdate_label1 = new JLabel("Expiration Date :");
        expirationdate_label1.setBounds(42, 430, 200, 24);
        expirationdate_label1.setFont(new Font("Arial", Font.BOLD, 21));
        
        
        // Create a JLabel object for the Issuer Bank for the Debit Card panel
        issuerbank_label1 = new JLabel("Issuer Bank :");
        issuerbank_label1.setBounds(595, 397, 130, 24);
        issuerbank_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Issuer Bank for the credit Card panel
        issuerbank_label2 = new JLabel("Issuer Bank :");
        issuerbank_label2.setBounds(594, 430, 130, 24);
        issuerbank_label2.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Credit Limit  for the credit Card panel
        creditlimit_label1 = new JLabel("Credit Limit :");
        creditlimit_label1.setBounds(588, 525, 150, 24);
        creditlimit_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the grace period for the credit Card panel
        graceperiod_label1 = new JLabel("Grace Period :");
        graceperiod_label1.setBounds(42, 605, 150, 24);
        graceperiod_label1.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the card id  for the set credit limit panel
        cardid_label3_credit = new JLabel("Card Id :");
        cardid_label3_credit.setBounds(42, 525, 200, 24);
        cardid_label3_credit.setFont(new Font("Arial", Font.BOLD, 21));
        

        // heading for withdraw panel
        heading_3 = new JLabel(
                "<html><span style='font-size: 24px; font-weight: bold; text-shadow: 2px 2px 2px #000; color:#2C5484; '> WITHDRAW FROM DEBIT CARD</span></html>");
        heading_3.setBounds(240, 1, 600, 70);
        

        //label for withdraw panel
        cardid_label3 = new JLabel("Card Id:");
        cardid_label3.setBounds(425, 99, 150, 29);
        cardid_label3.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Withdrawal Amount for the withdraw panel
        withdrawalamount_label3 = new JLabel("Withdrawal Amount:");
        withdrawalamount_label3.setBounds(378, 340, 209, 29);
        withdrawalamount_label3.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Date Of Withdrawal for the withdraw panel
        dateofwithdrawal_label3 = new JLabel("Date Of Withdrawal:");
        dateofwithdrawal_label3.setBounds(375, 210, 215, 29);
        dateofwithdrawal_label3.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Create a JLabel object for the Pin Number for the withdraw panel
        pinnumber_label3 = new JLabel("Pin Number :");
        pinnumber_label3.setBounds(408, 449, 150, 24);
        pinnumber_label3.setFont(new Font("Arial", Font.BOLD, 21));
        

        // Creating a new text field for inputting client name for debit card
        clientname_input1 = new JTextField();
        clientname_input1.setBounds(24, 141, 365, 45);
        clientname_input1.setFont(new Font("Arial", Font.BOLD, 15));
        
        
        // Creating a new text field for inputting client name for credit card
        clientname_input2 = new JTextField();
        clientname_input2.setBounds(42, 134, 365, 37);
        clientname_input2.setFont(new Font("Arial", Font.BOLD, 15));
        
        
        // Creating a new text field for inputting client name for withdraw panel
        cardid_input1 = new JTextField();
        cardid_input1.setBounds(595, 141, 365, 45);
        cardid_input1.setFont(new Font("Arial", Font.BOLD, 15));
        
        
       // Creating a new text field for inputting client name for set credit limit panel
        cardid_input2 = new JTextField();
        cardid_input2.setBounds(588, 134, 365, 37);
        cardid_input2.setFont(new Font("Arial", Font.BOLD, 15));
        
       
        // Creating a new text field for inputting bank account information for debit card
        bankaccount_input1 = new JTextField();
        bankaccount_input1.setBounds(24, 291, 365, 45);
        bankaccount_input1.setFont(new Font("Arial", Font.BOLD, 15));
        

        // Creating a new text field for inputting bank account information for credit card
        bankaccount_input2 = new JTextField();
        bankaccount_input2.setBounds(42, 245, 365, 37);
        bankaccount_input2.setFont(new Font("Arial", Font.BOLD, 15));
        

        // Creating a new text field for inputting bank amount information for debit card
        bankamount_input1 = new JTextField();
        bankamount_input1.setBounds(595, 291, 365, 45);
        bankamount_input1.setFont(new Font("Arial", Font.BOLD, 15));
        

        // Creating a new text field for inputting bank amount information for credit card
        bankamount_input2 = new JTextField();
        bankamount_input2.setBounds(588, 245, 365, 37);
        bankamount_input2.setFont(new Font("Arial", Font.BOLD, 15));
        
        
        // Creating a new text field for inputting pin input information for credit card
        pin_input1 = new JTextField();
        pin_input1.setBounds(24, 433, 365, 45);
        pin_input1.setFont(new Font("Arial", Font.BOLD, 15));
        
     
        // Creating a new text field for inputting cvc input information for credit card
        cvc_input1 = new JTextField();
        cvc_input1.setBounds(42, 357, 365, 37);
        cvc_input1.setFont(new Font("Arial", Font.BOLD, 15));
        
        
        // Creating a new text field for inputting interest rate information for credit card
        interestrate_input1 = new JTextField();
        interestrate_input1.setBounds(588, 357, 365, 37);
        interestrate_input1.setFont(new Font("Arial", Font.BOLD, 15));
        

        // Creating a new text field for inputting issuer bank information for debit card
        issuerbank_input1 = new JTextField();
        issuerbank_input1.setBounds(595, 433, 365, 45);
        issuerbank_input1.setFont(new Font("Arial", Font.BOLD, 15));
        

        // Creating a new text field for inputting issuer bank information for credit card
        issuerbank_input2 = new JTextField();
        issuerbank_input2.setBounds(588, 463, 365, 37);
        issuerbank_input2.setFont(new Font("Arial", Font.BOLD, 15));
        
        
        // Creating a new text field for inputting credit limit information for credit card
        creditlimit_input1 = new JTextField();
        creditlimit_input1.setBounds(588, 560, 365, 40);
        creditlimit_input1.setFont(new Font("Arial", Font.BOLD, 15));
        
        
       // Creating a new text field for inputting grace period information for credit card
        graceperiod_input1 = new JTextField();
        graceperiod_input1.setBounds(40, 640, 365, 37);
        graceperiod_input1.setFont(new Font("Arial", Font.BOLD, 15));
        
        
       // Creating a new text field for inputting card information for credit card to set credit limit
        cardid_input3_credit = new JTextField();
        cardid_input3_credit.setBounds(42, 558, 365, 37);
        cardid_input3_credit.setFont(new Font("Arial", Font.BOLD, 15));
        
        
       // Creating a new text field for inputting card id information for withdraw panel
        cardid_input3 = new JTextField();
        cardid_input3.setBounds(306, 150, 352, 37);
        cardid_input3.setFont(new Font("Arial", Font.BOLD, 15));
        
        
       // Creating a new text field for inputting withdraw information for withdraw panel
        withdrawalamount_input3 = new JTextField();
        withdrawalamount_input3.setBounds(306, 393, 352, 37);
        withdrawalamount_input3.setFont(new Font("Arial", Font.BOLD, 15));
        
        
        // Creating a new text field for inputting pin number information for withdraw panel
        pinnumber_input3 = new JTextField();
        pinnumber_input3.setBounds(307, 497, 352, 37);
        pinnumber_input3.setFont(new Font("Arial", Font.BOLD, 15));
        

        // withdraw form debit combo box  for choosing year of withdrawn
        String Wyear[] = { "Year", "2018", "2019", "2020", "2021", "2022", "2023" };
        withdrawaldate_year3 = new JComboBox<String>(Wyear);
        withdrawaldate_year3.setFont(new Font("Arial", Font.PLAIN, 18));
        withdrawaldate_year3.setBounds(306, 266, 111, 32);
        

        // withdraw form debit combo box  for choosing month of withdrawn
        String Wmonth[] = { "Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
        withdrawaldate_month3 = new JComboBox<String>(Wmonth);
        withdrawaldate_month3.setFont(new Font("Arial", Font.PLAIN, 18));
        withdrawaldate_month3.setBounds(443, 266, 78, 32);
        
        
        // withdraw form debit combo box  for choosing day of withdrawn
        String Wday[] = { "Day", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
                "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
        withdrawaldate_day3 = new JComboBox<String>(Wday);
        withdrawaldate_day3.setFont(new Font("Arial", Font.PLAIN, 18));
        withdrawaldate_day3.setBounds(547, 266, 111, 32);
        

        // expiration date  combo box  for choosing year 
        String Eyear[] = { "Year", "2023", "2024", "2025", "2026", "2027" };
        expirationdate_year = new JComboBox<String>(Eyear);
        expirationdate_year.setFont(new Font("Arial", Font.PLAIN, 18));
        expirationdate_year.setBounds(43, 470, 85, 32);
        
        
        // expiration date  combo box  for choosing month 
        String Emonth[] = { "Month", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12" };
        expirationdate_month = new JComboBox<String>(Emonth);
        expirationdate_month.setFont(new Font("Arial", Font.PLAIN, 18));
        expirationdate_month.setBounds(145, 470, 85, 32);

        
        // expiration date  combo box  for choosing day
        String Eday[] = { "Day", "01", "02", "03", "04", "05", "06", "07", "08", "09", "10", "11", "12", "13", "14",
                "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31" };
        expirationdate_day = new JComboBox<String>(Eday);
        expirationdate_day.setFont(new Font("Arial", Font.PLAIN, 18));
        expirationdate_day.setBounds(248, 470, 85, 32);
        

        // Create a new JButton object for withdraw
        withdraw_button = new JButton("WithDraw");
        withdraw_button.setBounds(13, 545, 121, 36);
        withdraw_button.setBackground(new Color(0, 10, 170));
        withdraw_button.setForeground(Color.WHITE);
        withdraw_button.setFont(new Font("Arial", Font.BOLD, 17));
        
        
        // Create a new JButton object for setting credit limit
        setcreditlimit_button = new JButton("Set CreditLimit");
        setcreditlimit_button.setBounds(785, 628, 185, 45);
        setcreditlimit_button.setBackground(new Color(0, 10, 170));
        setcreditlimit_button.setForeground(Color.WHITE);
        setcreditlimit_button.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Create a new JButton object for adding a debit card
        add_button1 = new JButton("Add Debit Card");
        add_button1.setBounds(755, 50, 200, 45);
        add_button1.setBackground(new Color(12, 73, 128, 255));
        add_button1.setForeground(Color.WHITE);
        add_button1.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Create a new JButton object for adding a credit card
        add_button2 = new JButton("Add Credit Card");
        add_button2.setBounds(740, 50, 200, 45);
        add_button2.setBackground(new Color(12, 73, 128, 255));
        add_button2.setForeground(Color.WHITE);
        add_button2.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Create a new JButton object for canceling a credit card
        cancelcredit_button = new JButton("Cancel Credit Card");
        cancelcredit_button.setBounds(588, 628, 185, 45);
        cancelcredit_button.setBackground(new Color(0, 10, 170));
        cancelcredit_button.setForeground(Color.WHITE);
        cancelcredit_button.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Create a new JButton object for displaying information of debit card
        display_button1 = new JButton("Display");
        display_button1.setBounds(153, 545, 121, 36);
        display_button1.setBackground(new Color(0, 10, 170));
        display_button1.setForeground(Color.WHITE);
        display_button1.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Create a new JButton object for displaying information of credit card
        display_button2 = new JButton("Display");
        display_button2.setBounds(13, 705, 121, 36);
        display_button2.setBackground(new Color(0, 10, 170));
        display_button2.setForeground(Color.WHITE);
        display_button2.setFont(new Font("Arial", Font.BOLD, 17));
        
        
        // Create a new JButton object for clearing information of debit card panel
        clear_button1 = new JButton("Clear");
        clear_button1.setBounds(293, 545, 121, 36);
        clear_button1.setBackground(new Color(220, 10, 0));
        clear_button1.setForeground(Color.WHITE);
        clear_button1.setFont(new Font("Arial", Font.BOLD, 17));
        
        
        // Create a new JButton object for clearing information of credit card panel
        clear_button2 = new JButton("Clear");
        clear_button2.setBounds(153, 705, 121, 36);
        clear_button2.setBackground(new Color(220, 10, 0));
        clear_button2.setForeground(Color.WHITE);
        clear_button2.setFont(new Font("Arial", Font.BOLD, 17));
        
        
        // Create a JButton for going to credit card section
        gotocredit_button = new JButton("GO TO CREDIT CARD");
        gotocredit_button.setBounds(755, 535, 210, 47);
        gotocredit_button.setBackground(new Color(34, 139, 34));
        gotocredit_button.setForeground(Color.WHITE);
        gotocredit_button.setFont(new Font("Arial", Font.BOLD, 17));
        
        
       // Create a JButton for going to debit card section
        gotodebit_button = new JButton("GO TO DEBIT CARD");
        gotodebit_button.setBounds(755, 703, 210, 40);
        gotodebit_button.setBackground(new Color(34, 139, 34));
        gotodebit_button.setForeground(Color.WHITE);
        gotodebit_button.setFont(new Font("Arial", Font.BOLD, 17));
        

        /// Create a JButton for proceeding with withdrawal from debit card
        proceed_button = new JButton("PROCEED");
        proceed_button.setBounds(812, 534, 155, 47);
        proceed_button.setBackground(new Color(15, 174, 127));
        proceed_button.setForeground(Color.WHITE);
        proceed_button.setFont(new Font("Arial", Font.BOLD, 17));
        
        
       // Create a JButton for going back to debit card
        goback_button = new JButton("GO BACK");
        goback_button.setBounds(21, 534, 155, 47);
        goback_button.setBackground(new Color(202, 11, 23));
        goback_button.setForeground(Color.WHITE);
        goback_button.setFont(new Font("Arial", Font.BOLD, 17));
        
        
        // Create a JButton for validation of input value of user for withdraw
        confirm_button = new JButton("CONFIRM");
        confirm_button.setBounds(353, 553, 117, 36);
        confirm_button.setBackground(new Color(38, 71, 187));
        confirm_button.setForeground(Color.WHITE);
        confirm_button.setFont(new Font("Arial", Font.BOLD, 17));
        
        
       // Create a JButton for validation of input value of user fow set credit limit
        confirm_button1 = new JButton("Confirm");
        confirm_button1.setBounds(460, 631, 110, 40);
        confirm_button1.setBackground(new Color(100, 10, 170));
        confirm_button1.setForeground(Color.WHITE);
        confirm_button1.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Create a JButton for clearing the input form
        clear_button3 = new JButton("CLEAR");
        clear_button3.setBounds(500, 553, 117, 36);
        clear_button3.setBackground(new Color(236, 39, 39));
        clear_button3.setForeground(Color.WHITE);
        clear_button3.setFont(new Font("Arial", Font.BOLD, 17));
        

        // Adding components to Jf JFRAME
        jf.add(jp);
        jf.add(jp2);
        jf.add(jp3);

        // Adding components to JP DEBIT CARD PANEL
        jp.add(heading_1);
        jp.add(clinetname_label1);
        jp.add(cardid_label1);
        jp.add(bankaccount_label1);
        jp.add(balanceamount_label1);
        jp.add(pinnumber_label1);
        jp.add(issuerbank_label1);

        jp.add(clientname_input1);
        jp.add(cardid_input1);
        jp.add(bankaccount_input1);
        jp.add(bankamount_input1);
        jp.add(pin_input1);
        jp.add(issuerbank_input1);

        jp.add(withdraw_button);
        jp.add(display_button1);
        jp.add(add_button1);
        jp.add(clear_button1);
        jp.add(gotocredit_button);

        // Adding components to JP2  CREDIT CARD PANEL
        jp2.add(heading_2);
        jp2.add(clinetname_label2);
        jp2.add(cardid_label2);
        jp2.add(bankaccount_label2);
        jp2.add(balanceamount_label2);
        jp2.add(pinnumber_label2);
        jp2.add(interestrate_label1);
        jp2.add(expirationdate_label1);
        jp2.add(issuerbank_label2);
        jp2.add(creditlimit_label1);
        jp2.add(graceperiod_label1);
        jp2.add(cardid_label3_credit);

        jp2.add(clientname_input2);
        jp2.add(cardid_input2);
        jp2.add(bankaccount_input2);
        jp2.add(bankamount_input2);
        jp2.add(cvc_input1);
        jp2.add(interestrate_input1);
        jp2.add(issuerbank_input2);
        jp2.add(creditlimit_input1);
        jp2.add(graceperiod_input1);
        jp2.add(cardid_input3_credit);
        jp2.add(pinnumber_input3);

        jp2.add(expirationdate_year);
        jp2.add(expirationdate_month);
        jp2.add(expirationdate_day);

        jp2.add(setcreditlimit_button);
        jp2.add(cancelcredit_button);
        jp2.add(display_button2);
        jp2.add(clear_button2);
        jp2.add(gotodebit_button);
        jp2.add(add_button2);
        jp2.add(confirm_button1);

        jp2.add(jp4);
        

        // Adding components to JP3  WITHDRAW PANEL
        jp3.add(heading_3);
        jp3.add(cardid_label3);
        jp3.add(withdrawalamount_label3);
        jp3.add(pinnumber_label3);
        jp3.add(dateofwithdrawal_label3);

        jp3.add(cardid_input3);
        jp3.add(withdrawalamount_input3);
        jp3.add(pinnumber_input3);

        jp3.add(withdrawaldate_year3);
        jp3.add(withdrawaldate_month3);
        jp3.add(withdrawaldate_day3);

        jp3.add(proceed_button);
        jp3.add(goback_button);
        jp3.add(confirm_button);
        jp3.add(clear_button3);
        

        // register the buttons for the event
        gotocredit_button.addActionListener(this);
        gotodebit_button.addActionListener(this);
        add_button1.addActionListener(this);
        add_button2.addActionListener(this);
        clear_button1.addActionListener(this);
        clear_button2.addActionListener(this);
        withdraw_button.addActionListener(this);
        goback_button.addActionListener(this);
        confirm_button.addActionListener(this);
        clear_button3.addActionListener(this);
        proceed_button.addActionListener(this);
        confirm_button1.addActionListener(this);
        cancelcredit_button.addActionListener(this);
        setcreditlimit_button.addActionListener(this);
        display_button1.addActionListener(this);
        display_button2.addActionListener(this);
        

        // disabling the button
        proceed_button.setEnabled(false);
        setcreditlimit_button.setEnabled(false);
        
        
        //disabling the focus of the buttons
        proceed_button.setFocusable(false);
        display_button2.setFocusable(false);
        display_button1.setFocusable(false);
        goback_button.setFocusable(false);
        confirm_button.setFocusable(false);
        clear_button3.setFocusable(false);
        confirm_button1.setFocusable(false);
        add_button2.setFocusable(false);
        add_button1.setFocusable(false);
        gotodebit_button.setFocusable(false);
        clear_button1.setFocusable(false);
        clear_button2.setFocusable(false);
        display_button2.setFocusable(false);
        cancelcredit_button.setFocusable(false);
        setcreditlimit_button.setFocusable(false);
        setcreditlimit_button.setFocusable(false);
        cancelcredit_button.setFocusable(false);
        display_button2.setFocusable(false);
        clear_button2.setFocusable(false);
        gotodebit_button.setFocusable(false);
        add_button2.setFocusable(false);
        confirm_button1.setFocusable(false);
        

       // Set the layout manager of jp, jp2, jp3, and jp4 to null
        jp.setLayout(null);
        jp2.setLayout(null);
        jp3.setLayout(null);
        jp4.setLayout(null);

        // Hide jp2 and jp3 panels
        jp2.setVisible(false);
        jp3.setVisible(false);

        // Prevent the JFrame from being resized
        jf.setResizable(false);

        // Set the layout manager of the JFrame to null
        jf.setLayout(null);

        // Make the JFrame visible
        jf.setVisible(true);

        // Set the default close operation of the JFrame to "EXIT_ON_CLOSE"
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    @Override
    public void actionPerformed(ActionEvent a) {
        
        /* When the "gotocredit_button" is clicked, the credit panel is shown
           and the debit panel is hidden. When the "gotodebit_button" is clicked,the debit panel is shown and the credit panel is hidden */
           
        if (a.getSource() == gotocredit_button) {
            jp.setVisible(false);
            jp2.setVisible(true);
            jf.setBounds(300, 20, 1000, 790);
            jp2.setSize(1000, 800);
        } else if (a.getSource() == gotodebit_button) {
            jp.setVisible(true);
            jp2.setVisible(false);
            jf.setBounds(300, 100, 1000, 640);

        }
        
        /* When the "withdraw_button" is clicked, the withdraw panel is shown
           and the debit panel is hidden. When the "goback_button is clicked,the debit is shown and the withdraw panel is hidden */

        if (a.getSource() == withdraw_button) {

            jp.setVisible(false);
            jp3.setVisible(true);

        } else if (a.getSource() == goback_button) {
            jp.setVisible(true);
            jp3.setVisible(false);
        }
        

        //Code to add the debit card Object to Array list of Bank card
        if (a.getSource() == add_button1) {
            
            //Code to add the debit card Object to Array list of Bank card
            
            String clientnameInput = clientname_input1.getText();
            
            String issuerBankInput = issuerbank_input1.getText();
            
            String bankAccount = bankaccount_input1.getText();
            
            String cardIdInput = cardid_input1.getText();
            
            String pinInput = pin_input1.getText();
            
            String balanceAmountInput = bankamount_input1.getText();

            // To Show an error message indicating that some fields are empty
            if (clientnameInput.isEmpty() || issuerBankInput.isEmpty() || bankAccount.isEmpty() || cardIdInput.isEmpty()
                    || pinInput.isEmpty() || balanceAmountInput.isEmpty()) {
                // Show an error message indicating that some fields are empty
                UIManager.put("OptionPane.minimumSize", new Dimension(350, 120));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "OPPS!  Please fill in all the fields.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            int cardId, pinnumber, balanceAmount;
            String clientname, issuerBank;
            

            try {
                cardId = Integer.parseInt(cardIdInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that cardId is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                pinnumber = Integer.parseInt(pinInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that pinnumber is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Pin Number should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                balanceAmount = Integer.parseInt(balanceAmountInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that balanceAmount is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(420, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Balance Amount should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                // Try to parse the input as a double
                double value = Double.parseDouble(clientnameInput);
                // If parsing succeeds, it means the input is a number, so show an error message
                UIManager.put("OptionPane.minimumSize", new Dimension(400, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));
                JOptionPane.showMessageDialog(null, "OPPS !  Client name cannot be a number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            } catch (NumberFormatException e) {
                // If parsing fails, it means the input is a string
                clientname = clientnameInput;
            }
            

            try {
                // Try to parse the input as a double
                double value = Double.parseDouble(issuerBankInput);
                // If parsing succeeds, it means the input is a number, so show an error message
                UIManager.put("OptionPane.minimumSize", new Dimension(450, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));
                JOptionPane.showMessageDialog(null, "OPPS !  Issuer Bank name cannot be a number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            } catch (NumberFormatException e) {
                // If parsing fails, it means the input is a string
                issuerBank = issuerBankInput;
            }
            

            /* The below code checks whether a given cardId exists in a list of bankCards. If the cardId does not exist, it creates a new DebitCard object with the given balanceAmount,
               cardId, bankAccount, issuerBank, clientname, and pinnumber, and adds it to the bankCards list. Finally, it displays a success message indicating that the DebitCard was
               added successfully.If the cardId already exists in the bankCards list, it displays an error message indicating that the cardId already exists and prompts the user to
               enter a different cardId.
            */
           
            boolean cardIdExists = false;
            for (BankCard card : bankCards) {
                if (card instanceof DebitCard) {
                    if (card.getCardId() == cardId) {
                        cardIdExists = true;
                        break;
                    }
                }
            }
            

            if (!cardIdExists) {
                DebitCard debitCard = new DebitCard(balanceAmount, cardId, bankAccount, issuerBank, clientname,
                        pinnumber);

                bankCards.add(debitCard);

                UIManager.put("OptionPane.minimumSize", new Dimension(380, 150));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));
                JOptionPane.showMessageDialog(null,
                        "DEBIT CARD ADDED SUCCESSFULLY ! \n Client Name: " + clientname + "\n Issuer Bank: "
                                + issuerBank + "\n Bank Account: " + bankAccount + "\n Card ID: " + cardId
                                + "\n Pin Number: " + pinnumber + "\n Balance Amount: $" + balanceAmount,
                        "Message", JOptionPane.INFORMATION_MESSAGE);

            } else {
                // Show an error message indicating that the card ID already exists
                UIManager.put("OptionPane.minimumSize", new Dimension(500, 160));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID already exists! Please enter a different Card ID.",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        //Code to add the credit card Object to Array list of Bank card
        if (a.getSource() == add_button2) {
            
            //to get value from input field and add it in the variable
            
            String clientnameInput = clientname_input2.getText();

            String issuerBankInput = issuerbank_input2.getText();

            String bankAccount = bankaccount_input2.getText();

            String cardIdInput = cardid_input2.getText();

            String balanceAmountInput = bankamount_input2.getText();

            String CVCnumberInput = cvc_input1.getText();

            String interestrateInput = interestrate_input1.getText();

            String year = (String) expirationdate_year.getSelectedItem();
            String month = (String) expirationdate_month.getSelectedItem();
            String day = (String) expirationdate_day.getSelectedItem();
            String expirationDate = year + "-" + month + "-" + day;
            
             // To Show an error message indicating that some fields are empty
            if (clientnameInput.isEmpty() || issuerBankInput.isEmpty() || bankAccount.isEmpty() || cardIdInput.isEmpty()
                    || CVCnumberInput.isEmpty() || balanceAmountInput.isEmpty() || interestrateInput.isEmpty()
                    || year.equals("Year") || month.equals("Month") || day.equals("Day")) {
                
                UIManager.put("OptionPane.minimumSize", new Dimension(350, 120));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "OPPS! Please fill in all the fields.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            int cardId, balanceAmount, cvcnumber;
            double interestrate;
            String clientname, issuerBank;
            

            try {

                balanceAmount = Integer.parseInt(balanceAmountInput);

            } catch (NumberFormatException e) {
                // Show an error message indicating that balanceAmount is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(420, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Balance Amount should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                cardId = Integer.parseInt(cardIdInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that cardId is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            try {
                cvcnumber = Integer.parseInt(CVCnumberInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that cvcnumber is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "CVC number should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            try {
                interestrate = Double.parseDouble(interestrateInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that interestrate is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(400, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Interest Rate should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                // Try to parse the input as a double
                double value = Double.parseDouble(clientnameInput);
                // If parsing succeeds, it means the input is a number, so show an error message
                UIManager.put("OptionPane.minimumSize", new Dimension(400, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));
                JOptionPane.showMessageDialog(null, "OPPS !  Client name cannot be a number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            } catch (NumberFormatException e) {
                // If parsing fails, it means the input is a string
                clientname = clientnameInput;
            }

            
            try {
                // Try to parse the input as a double
                double value = Double.parseDouble(issuerBankInput);
                // If parsing succeeds, it means the input is a number, so show an error message
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));
                UIManager.put("OptionPane.minimumSize", new Dimension(450, 130));
                JOptionPane.showMessageDialog(null, "OPPS !  Issuer Bank name cannot be a number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            } catch (NumberFormatException e) {
                // If parsing fails, it means the input is a string
                issuerBank = issuerBankInput;
            }

            
            /* The below code checks whether a given cardId exists in a list of bankCards. If the cardId does not exist, it creates a new CreditCard object and adds it to the bankCards
               list and it displays a success message indicating that the Credit Card was added successfully.If the cardId already exists in the bankCards list, it displays an error
               message indicating that the cardId already exists and prompts the user to enter a different cardId.
            */
                        
            boolean cardIdExists = false;
            for (BankCard card : bankCards) {
                if (card instanceof CreditCard) {
                    if (card.getCardId() == cardId) {
                        cardIdExists = true;
                        break;
                    }
                }
            }

            
            if (!cardIdExists) {

                CreditCard creditCard = new CreditCard(cardId, clientname, issuerBank, bankAccount, balanceAmount,
                        cvcnumber, interestrate, expirationDate);

                bankCards.add(creditCard);

                UIManager.put("OptionPane.minimumSize", new Dimension(380, 150));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null,
                        "CREDIT CARD ADDED SUCCESSFULLY ! \n Client Name: " + clientname + "\n Issuer Bank: "
                                + issuerBank + "\n Bank Account: " + bankAccount + "\n Card ID: " + cardId
                                + "\n Balance Amount: $" + balanceAmount + "\n CVC Number: " + cvcnumber
                                + "\n Interest Rate: " + interestrate + "\n Expiration Date: " + expirationDate,
                        "Message", JOptionPane.INFORMATION_MESSAGE);
            }

            else {

                UIManager.put("OptionPane.minimumSize", new Dimension(395, 160));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID already exists ! Please Enter a different Card ID.",
                        "Error", JOptionPane.ERROR_MESSAGE);

            }

        }

        // to clear input values of debit panel
        if (a.getSource() == clear_button1) {

            clientname_input1.setText("");
            issuerbank_input1.setText("");
            bankaccount_input1.setText("");
            cardid_input1.setText("");
            pin_input1.setText("");
            bankamount_input1.setText("");

        }

        // to clear input values of withdraw panel
        if (a.getSource() == clear_button3) {

            withdrawalamount_input3.setText("");
            cardid_input3.setText("");
            pinnumber_input3.setText("");
            withdrawaldate_year3.setSelectedIndex(0);
            withdrawaldate_month3.setSelectedIndex(0);
            withdrawaldate_day3.setSelectedIndex(0);

        }

        // to clear input values of credit panel
        if (a.getSource() == clear_button2) {

            clientname_input2.setText("");
            issuerbank_input2.setText("");
            bankaccount_input2.setText("");
            cardid_input2.setText("");
            pin_input1.setText("");
            bankamount_input2.setText("");
            cvc_input1.setText("");
            interestrate_input1.setText("");
            graceperiod_input1.setText("");
            creditlimit_input1.setText("");
            cardid_input3_credit.setText("");
            expirationdate_year.setSelectedIndex(0);
            expirationdate_month.setSelectedIndex(0);
            expirationdate_day.setSelectedIndex(0);

        }

        // after clicking confirm button to display info
        if (a.getSource() == confirm_button) {

            String cardIdInput = cardid_input3.getText();
            
            String withdrawalamountInput = withdrawalamount_input3.getText();
            
            String pinnumberInput = pinnumber_input3.getText();
            
            String year = (String) withdrawaldate_year3.getSelectedItem();
            
            String month = (String) withdrawaldate_month3.getSelectedItem();
            
            String day = (String) withdrawaldate_day3.getSelectedItem();
            
            String withdrawaldate = year + "-" + month + "-" + day;
            
             // To Show an error message indicating that some fields are empty
            if (cardIdInput.isEmpty() || withdrawalamountInput.isEmpty() || pinnumberInput.isEmpty()
                    || year.equals("Year") || month.equals("Month") || day.equals("Day")) {
                
                UIManager.put("OptionPane.minimumSize", new Dimension(350, 120));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "OPPS!  Please fill in all the fields.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            int cardId, withdrawalamount, pinnumber;
            

            try {
                cardId = Integer.parseInt(cardIdInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that cardId is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                withdrawalamount = Integer.parseInt(withdrawalamountInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that withdrawalamount is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(430, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "withdrawal Amount should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            try {
                pinnumber = Integer.parseInt(pinnumberInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that pinnumber is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(400, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Pin Number should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            
            //  the below code is to enable the proceed button for withdraw if the card id is entered is valid
            
            boolean cardIdExists = false;
            for (BankCard card : bankCards) {
                if (card instanceof DebitCard) {
                    if (card.getCardId() == cardId) {

                        // Display success message with values and set dialog size
                        UIManager.put("OptionPane.minimumSize", new Dimension(350, 200));
                        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 17));
                        JOptionPane.showMessageDialog(null,
                                "Card ID: " + cardId + "\n\nWithdrawal Date: " + withdrawaldate
                                        + "\n\nWithdrawal Amount: $ " + withdrawalamount + "\n\nPIN Number: "
                                        + pinnumber,
                                "CONFIRM", JOptionPane.INFORMATION_MESSAGE);
                        proceed_button.setEnabled(true);
                        cardIdExists = true;
                        break;
                    }
                }
            }

            
            if (!cardIdExists) {

                UIManager.put("OptionPane.minimumSize", new Dimension(500, 130));
                JOptionPane.showMessageDialog(null, "  Invalid Card ID !  Please Enter Your Correct Card Id ",
                        "Message", JOptionPane.INFORMATION_MESSAGE);

            }

        }

        // the proceed button is for calling withdraw method of debit card 
        
        if (a.getSource() == proceed_button) {

           //to get value from input field and store it in variable
            
            int cardId = Integer.parseInt(cardid_input3.getText());
            
            int withdrawalamount = Integer.parseInt(withdrawalamount_input3.getText());
            
            String year = (String) withdrawaldate_year3.getSelectedItem();
            
            String month = (String) withdrawaldate_month3.getSelectedItem();
            
            String day = (String) withdrawaldate_day3.getSelectedItem();
            
            String withdrawaldate = year + "-" + month + "-" + day;

            int pinnumber = Integer.parseInt(pinnumber_input3.getText());

            for (BankCard card : bankCards) {
                if (card instanceof DebitCard) {
                    if (card.getCardId() == cardId) {

                        ((DebitCard) card).withdraw(withdrawalamount, withdrawaldate, pinnumber);
                        UIManager.put("OptionPane.minimumSize", new Dimension(370, 100));
                        JOptionPane.showMessageDialog(null, "Withdraw Process Is Successfully Done !", "Message",
                                JOptionPane.INFORMATION_MESSAGE);
                        proceed_button.setEnabled(false);
                        break;
                    }

                }
            }

        }

        if (a.getSource() == confirm_button1) {
            
            String cardIdInput = cardid_input3_credit.getText();
            
            String graceperiodInput = graceperiod_input1.getText();
            
            String creditlimitInput = creditlimit_input1.getText();

            if (cardIdInput.isEmpty() || graceperiodInput.isEmpty() || creditlimitInput.isEmpty()) {
                // Show an error message indicating that some fields are empty
                UIManager.put("OptionPane.minimumSize", new Dimension(480, 120));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "OPPS!  Please fill in all the fields To Set Credit Limit", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            int cardId, graceperiod;
            double creditlimit;
            

            try {
                cardId = Integer.parseInt(cardIdInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that cardId is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }
            

            try {
                graceperiod = Integer.parseInt(graceperiodInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that graceperiod is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Grace Period should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            try {
                creditlimit = Double.parseDouble(creditlimitInput);

            } catch (NumberFormatException e) {
                // Show an error message indicating that creditlimit is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Credit Limit should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            
            //  the below code is to enable the set credit limit button if the card id is entered is valid
            
            boolean cardIdExists = false;
            for (BankCard card : bankCards) {

                if (card instanceof CreditCard) {
                    if (card.getCardId() == cardId) {

                        // Display success message with values and set dialog size
                        UIManager.put("OptionPane.minimumSize", new Dimension(320, 150));
                        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 17));
                        JOptionPane.showMessageDialog(null, "Card ID: " + cardId + "\n\n Credit Limit: " + creditlimit
                                + "\n\n Grace Period: " + graceperiod, "CONFIRM", JOptionPane.INFORMATION_MESSAGE);
                        setcreditlimit_button.setEnabled(true);
                        cardIdExists = true;

                        break;
                    }
                }
            }

            if (!cardIdExists) {

                UIManager.put("OptionPane.minimumSize", new Dimension(470, 120));
                JOptionPane.showMessageDialog(null,
                        "  Invalid Card ID !  Please Enter Your Correct Card Id\n\n  To Set Credit Limit. ", "Message",
                        JOptionPane.INFORMATION_MESSAGE);

            }

        }

        
        
        if (a.getSource() == cancelcredit_button) {

            String cardIdInput = cardid_input3_credit.getText();

            if (cardIdInput.isEmpty()) {
                UIManager.put("OptionPane.minimumSize", new Dimension(360, 120));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "OPPS!  Please Enter The Card Id field.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return;
            }

            int cardId;

            try {
                cardId = Integer.parseInt(cardIdInput);
            } catch (NumberFormatException e) {
                // Show an error message indicating that cardId is not a valid number
                UIManager.put("OptionPane.minimumSize", new Dimension(370, 130));
                UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 15));

                JOptionPane.showMessageDialog(null, "Card ID should be a valid number.", "Error",
                        JOptionPane.ERROR_MESSAGE);
                return; // Return from the method as further processing is not possible
            }

            // if the existing card id of credit card matches with the user input card it the credit card will be cancel
            
            boolean cardIdExists = false;
            for (BankCard card : bankCards) {
                if (card instanceof CreditCard) {
                    if (card.getCardId() == cardId) {

                        // Display success message with values and set dialog size
                        ((CreditCard) card).cancelCreditCard();
                        UIManager.put("OptionPane.minimumSize", new Dimension(520, 200));
                        UIManager.put("OptionPane.messageFont", new Font("Arial", Font.BOLD, 17));
                        JOptionPane.showMessageDialog(null,
                                "Cancellation  Of Credit Card Is Done Successfully !\n\n cvcNumber: 0\n\n creditLimit: 0\n\ngracePeriod: 0 ",
                                "Message", JOptionPane.INFORMATION_MESSAGE);
                        cardIdExists = true;

                        break;
                    }
                }
            }

            
            if (!cardIdExists) {

                UIManager.put("OptionPane.minimumSize", new Dimension(470, 70));
                JOptionPane.showMessageDialog(null, "  Invalid Card ID ! Please Enter Your Correct Card Id ", "Message",JOptionPane.INFORMATION_MESSAGE);

            }

        }
        
        // to set the credit limit of the credit card
        
         if (a.getSource() == setcreditlimit_button)

        {
            int cardId = Integer.parseInt(cardid_input3_credit.getText());
            
            double creditlimit = Double.parseDouble(creditlimit_input1.getText());
            
            int graceperiod = Integer.parseInt(graceperiod_input1.getText());

            boolean cardIdExists = false;
            for (BankCard card : bankCards) {
                if (card instanceof CreditCard) {
                    if (card.getCardId() == cardId) {

                        ((CreditCard) card).setCreditLimit(creditlimit, graceperiod);
                        cardIdExists = true;
                        setcreditlimit_button.setEnabled(false);
                        UIManager.put("OptionPane.minimumSize", new Dimension(350, 100));
                        JOptionPane.showMessageDialog(null, "Credit Limit Is Set Successfully !", "Message",JOptionPane.INFORMATION_MESSAGE);

                        break;
                    }
                }
            }

        }
        
        // to display the information of debit card
        
        if (a.getSource() == display_button1) {

            for (BankCard card : bankCards) {
                if (card instanceof DebitCard) {
                    System.out.println();
                    System.out.println();
                    System.out.println("CARD TYPE: DEBIT CARD");
                    ((DebitCard) card).display();
                    System.out.println();
                    System.out.println();
                }

            }

        }
        
        // to display the information of credit card
        
        if (a.getSource() == display_button2) {

            for (BankCard card : bankCards) {
                if (card instanceof CreditCard) {
                    System.out.println();
                    System.out.println();
                    System.out.println("CARD TYPE: CREDIT CARD");
                    ((CreditCard) card).display();
                    System.out.println();
                    System.out.println();
                }

            }

        }

    }

    public static void main(String args[]) {
        new BankGui();

    }
}
